/*
 * LED2 CODE.c
 *
 * Created: 9/18/2023 9:49:02 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>


int main(void)
{
	DDRJ = 0x00; //input
	DDRK = 0xff; //output
    /* Replace with your application code */
    while (1) 
    {
		if((PINJ&0x08)==0x00){  //switch is closed or on, 0x08==0b000001000-mask
			PORTK |= (1<<1); //LED lights, active high
    } else{
		PORTK &= ~(1<<1); }//LED is off
	}
}

