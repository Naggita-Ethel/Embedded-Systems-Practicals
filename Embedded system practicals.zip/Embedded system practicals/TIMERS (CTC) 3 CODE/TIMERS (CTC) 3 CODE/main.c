/*
 * TIMERS (CTC) 3 CODE.c
 *
 * Created: 10/1/2023 5:39:43 PM
 * Author : ADMIN
 */ 
//1MHz frequency, CTC mode, no prescaling, timer2 (8 bits), delay of 2 seconds
#include <avr/io.h>
#define F_CPU 1000000ul
//#include <avr/interrupt.h>
int count = 0;
int main(void)
{
	
	DDRD = 0XFF;
	TCCR2 |= (1<<CS00); //setting for no prescaling
	TCNT2 = 0X00; //setting to start counting from 0
	TCCR2 |= (1<<WGM01); //CTC MODE
	OCR2 = 200; //0xC8, setting timer to stop at 200 microseconds before overflow
	//sei(); //enable global interrupts
	//EIMSK |= (1<<INT1); //enabling interrupts at int1 pin
	//TIMSK |= (1<<TOIE0); //enabling interrupts for timers
	/* Replace with your application code */
	while (1)
	{
		while((TIFR&0B10000000)>0){ //polling, while there is a match
			count++;
			if(count==10000){  //2000000/200=10000
				PORTD ^= (1<<1); //toggle led
				//count = 0;
			}
			TIFR &= ~(1<<OCF2); //unsetting the OCF2 bit after a match
		}
		
	}
}
/*ISR(TIMER0_OVF_vect){  //setting an interrupt after one second
	count++;
	if(count==3922){  //3922 times of overflows are roughly needed to make a second, 1000000/255=3922
		PORTD ^= (1<<1); //toggle led
		count = 0;
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
}*/



