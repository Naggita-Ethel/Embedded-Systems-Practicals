/*
 * TIMERS (NORMAL MODE) 1 CODE.c
 *
 * Created: 9/30/2023 9:49:33 PM
 * Author : ADMIN
 */ 
#define F_CPU 1000000ul
#include <avr/io.h>

//delay of 1 sec for 1MHz frequency, normal mode
int main(void)
{
	int count = 0;
	DDRD = 0XFF;
	TCCR0 |= (1<<CS00); //setting for no prescaling
	TCNT0 = 0X00; //setting to start counting from 0
    /* Replace with your application code */
    while (1) 
    {
		while((TIFR&0B00000001)>0){ //pollling, while there is an overflow
			count++;
			if(count==3922){  //3922 times of overflows are roughly needed to make a second, 1000000/255=3922
				PORTD ^= (1<<1); //toggle led
				//count = 0;
			}
			TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
		}
		
    }
}

