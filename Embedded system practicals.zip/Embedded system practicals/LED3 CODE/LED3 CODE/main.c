/*
 * LED3 CODE.c
 *
 * Created: 9/27/2023 3:20:28 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>


int main(void)
{
	DDRH = 0B10111111; // DDRH |= (1<<5) | ~(1<<6); //bit 5-output (led), bit 6-input (switch)
	
    /* Replace with your application code */
    while (1) 
    {
		if ((PINH&0B01000000)==0X00){
			PORTH |=(1<<5);
		}else{
			PORTH&= ~(1<<5);
		}
		
    }
}

