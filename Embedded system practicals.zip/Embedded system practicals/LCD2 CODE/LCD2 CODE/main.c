/*
 * LCD2 CODE.c
 *
 * Created: 9/27/2023 5:30:09 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
	DDRG = 0XFF;
	DDRH = 0XFF;
	char word[] ="welcome";
    /* Replace with your application code */
    while (1) 
    {
		PORTG &= ~(1<<0); //RS-0-COMMAND
		PORTG &= ~(1<<1); //RW-0-WRITE
		
		//turn display on, cursor on and blink
		PORTH = 0B00001111;
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(1000);
		PORTG |= (1<<2); //setting it to high (1)
		
		//function set
		//PORTH = 0b00111011;
		//PORTG &= ~(1<<2); //putting 0 at enable pin
		//_delay_ms(1000);
		//PORTG |= (1<<2); //putting 1 at enable pin
		
		//clearing screen
		PORTH = 0b00000001;
		PORTG &= ~(1<<2); //putting 0 at enable pin
		_delay_ms(1000);
		PORTG |= (1<<2); //putting 1 at enable pin
		
		
		//printing welcome
		PORTG |= (1<<0); //DATA MODE RS
		for (int y=0; y<7; y++){
			PORTH = word[y];
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			
		}
		
		
		//printing the word in the middle
		//PORTH = 0XC5;
		//PORTG &= ~(1<<2); //putting 0 at enable pin
		//_delay_ms(1);
		//PORTG |= (1<<2); //putting 1 at enable pin
		
		
    }
}

