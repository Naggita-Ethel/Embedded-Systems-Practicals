/*
 * KEYPAD1 CODE.c
 *
 * Created: 9/19/2023 3:31:23 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>


int main(void)
{
	DDRH = 0b11111000; // 0b11111000, row-input (00),column- output (111111)
	DDRF = 0xff;
    /* Replace with your application code */
    while (1) 
    {
		PORTH = 0b11011111; //setting column 1 to have a 0 for testing
		if((PINH&0b00000001)==0x00){ //if there is a 0 at row 1, then 1 is pressed
			PORTF |= (1<<0); //light LED 1
			}if((PINH&0b00000010)==0x00){ //if there is a 0 at row 2, then 4 is pressed
				PORTF |= (1<<3);
				 //light LED 4
			}if((PINH&0b00000100)==0x00){ //if there is a zero at row 3, then 8 is pressed
			PORTF |= (1<<6); //light LED 8
		}
			
			
			PORTH = 0b11101111; //setting column 2 to 0 for testing
			if((PINH&0b00000001)==0x00){ //if there is a 0 at row 1, then 2 is pressed
				PORTF |= (1<<1); //light LED 2
				}if((PINH&0b00000010)==0x00){ //if there is a 0 at row 2, then 5 is pressed
				PORTF |= (1<<4); //light LED 5
				}if((PINH&0b00000100)==0x00){ //if there is a zero at row 3, then 8 is pressed
				PORTF |= (1<<7); //light LED 8
			}
			
			
			PORTH = 0b11110111; //setting column 3 to 0 for testing
			if((PINH&0b00000001)==0x00){ //if there is a 0 at row 1, then 3 is pressed
				PORTF |= (1<<2); //light LED 3
				}if((PINH&0b00000010)==0x00){ //if there is a 0 at row 2, then 6 is pressed
				PORTF |= (1<<5); //light LED 6
				}
				
				
			
			
	}
			
}

