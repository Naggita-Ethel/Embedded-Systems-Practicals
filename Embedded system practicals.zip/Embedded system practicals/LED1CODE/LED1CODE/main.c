/*
 * LED1CODE.c
 *
 * Created: 9/17/2023 10:36:39 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>


int main(void)
{
	DDRK = 0xff;
	//int i;
    /* Replace with your application code */
    while (1) 
    {
		PORTK &= ~(1<<0);
		PORTK |= (1<<2);
		//PORTK = 0x00;
		//for(i=0;i<10000;i++);
		//PORTK = 0xff;
		//for(i=0;i<10000;i++);
    }
}

