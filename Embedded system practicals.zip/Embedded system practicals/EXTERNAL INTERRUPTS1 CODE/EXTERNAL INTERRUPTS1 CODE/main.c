/*
 * EXTERNAL INTERRUPTS1 CODE.c
 *
 * Created: 9/30/2023 4:23:51 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

//lighting the led on falling edge
int main(void)
{
	DDRD = 0X00;
	DDRE = 0XFF;
	sei(); //enabling global interrupts using the i bit of the sreg register
	EIMSK |= (1<<INT3); //enabling interrupts at int3 port 
	
    /* Replace with your application code */
    while (1) 
    {
    }
}
ISR(INT3_vect){
	PORTE ^= (1<<0); //TOGGLE THE LED
}
