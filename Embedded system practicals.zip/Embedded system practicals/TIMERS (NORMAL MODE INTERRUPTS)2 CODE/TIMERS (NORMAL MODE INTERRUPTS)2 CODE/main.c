/*
 * TIMERS (NORMAL MODE INTERRUPTS)2 CODE.c
 *
 * Created: 10/1/2023 3:56:59 PM
 * Author : ADMIN
 */ 
//1MHz frequency, normal mode, no prescaling, creating a delay of 1 second using interrupts, timer0(8 bits)
#define F_CPU 1000000ul
#include <avr/interrupt.h>
int count = 0;
int main(void)
{
	
	DDRD = 0XFF;
	TCCR0 |= (1<<CS00); //setting for no prescaling
	TCNT0 = 0X00; //setting to start counting from 0
	sei(); //enable global interrupts
	EIMSK |= (1<<INT1); //enabling interrupts at int1 pin
	TIMSK |= (1<<TOIE0); //enabling interrupts for timers
	/* Replace with your application code */
	while (1)
	{
		/*while((TIFR&0B00000001)>0){ //pollling, while there is an overflow
			count++;
			if(count==3922){  //3922 times of overflows are roughly needed to make a second, 1000000/255=3922
				PORTD ^= (1<<1); //toggle led
				count = 0;
			}
			TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
		}*/
		
	}
}
ISR(TIMER0_OVF_vect){  //setting an interrupt after one second
	count++;
	if(count==3922){  //3922 times of overflows are roughly needed to make a second, 1000000/255=3922
		PORTD ^= (1<<1); //toggle led
		count = 0;
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
}