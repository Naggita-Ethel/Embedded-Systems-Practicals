/*
 * EXTERNAL INTERRUPTS2 CODE.c
 *
 * Created: 9/30/2023 4:59:10 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

int main(void)
{
	DDRD = 0X00;
	DDRE = 0XFF;
	sei(); //enabling global interrupts using the i bit of the sreg register
	EIMSK |= (1<<INT0); //enabling interrupts at int0 port
	//EICRA |= (1<<ISC01); //on falling edge
	//on raising edge
	EICRA |= (1<<ISC01);
	EICRA |= (1<<ISC00);
    /* Replace with your application code */
    while (1) 
    {
    }
}ISR(INT0_vect){ 
	PORTE ^=(1<<0); //toggling the led
}


