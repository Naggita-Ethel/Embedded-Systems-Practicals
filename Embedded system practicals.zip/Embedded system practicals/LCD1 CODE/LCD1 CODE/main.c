/*
 * LCD1 CODE.c
 *
 * Created: 9/27/2023 3:59:53 PM
 * Author : ADMIN
 */ 

#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
	DDRG = 0XFF;
	DDRH = 0XFF;
    /* Replace with your application code */
    while (1) 
    {
		PORTG &= ~(1<<0); //RS-0-COMMAND
		PORTG &= ~(1<<1); //RW-0-WRITE
		
		//turn display on, cursor on and blink
		PORTH = 0B00001111;
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(100);
		PORTG |= (1<<2); //setting it to high (1)
		
		//function set
		PORTH = 0B00111111;
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(100);
		PORTG |= (1<<2); //setting it to high (1)
		
		//shifting cursor from r to l on display
		PORTH = 0B00011100;
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(100);
		PORTG |= (1<<2); //setting it to high (1)
		
		//clearing screen
		PORTH = 0B00000001;
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(100);
		PORTG |= (1<<2); //setting it to high (1)
		
		//data mode
		PORTG |= (1<<0); 
		
		//printing an A
		PORTH = 'A';
		//latching
		PORTG &= ~(1<<2); //setting enable (e) to 0
		_delay_ms(100);
		PORTG |= (1<<2); //setting it to high (1)
		
		
    }
}

