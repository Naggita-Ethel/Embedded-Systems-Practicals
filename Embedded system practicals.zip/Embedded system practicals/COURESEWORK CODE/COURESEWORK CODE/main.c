
#define EEWE 1
#define EEMWE 2
#define F_CPU 8000000ul
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/eeprom.h>
int count = 0;


//serial communication
#define FOSC 1000000// Clock Speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

void USART_Init( unsigned int ubrr )
{
	/* Set baud rate */
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	/* Enable receiver and transmitter */
	UCSR0B = (1<<RXEN)|(1<<TXEN);
	/* Set frame format: 8data, 2stop bit */
	UCSR0C = (1<<USBS)|(3<<UCSZ0);
}

void USART_Transmit( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

void USART_Transmit_str( unsigned char str[] ){
	int length=strlen(str);
	for (int i=0; i<length; i++){
		/* Wait for empty transmit buffer */
		while ( !( UCSR0A & (1<<UDRE0)) );
		/* Put data into buffer, sends the data */
		UDR0 = str[i];
	}
	
}

char USART_Receive( ){
	/* Wait for data to be received */
	while ( !(UCSR0A & (1<<RXC0)) );
	/* Get and return received data from buffer */
	return UDR0;
}

//writing to eeprom
//void EEPROM_write(unsigned int uiAddress, const char *str)
//{
	//int length = strlen(str);

	//for (int i = 0; i < length; i++) {
		/* Wait for completion of previous write */
		//while (EECR & (1 << EEWE));
		/* Set up address and data registers */
		//EEAR = uiAddress + i;
		//EEDR = str[i];
		/* Write logical one to EEMWE */
		//EECR |= (1 << EEMWE);
		/* Start EEPROM write by setting EEWE */
		//EECR |= (1 << EEWE);
	//}
//}

//void EEPROM_write(unsigned int uiAddress, unsigned char str[])
//{
	/* Wait for completion of previous write */
	//int length=strlen(str);
	//for (int i=0; i<length; i++){
		/* Wait for empty transmit buffer */
		//while(EECR & (1<<EEWE));
		/* Set up address and data registers */
		//EEAR = uiAddress;
		//EEDR = str[i];
	//}
	/* Write logical one to EEMWE */
	//EECR |= (1<<EEMWE);
	/* Start eeprom write by setting EEWE */
	//EECR |= (1<<EEWE);
//}

/*void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{
	/* Wait for completion of previous write */
	//while(EECR & (1<<EEWE));
	/* Set up address and data registers */
	//EEAR = uiAddress;
	//EEDR = ucData;
	/* Write logical one to EEMWE */
	//EECR |= (1<<EEMWE);
	/* Start eeprom write by setting EEWE */
	//EECR |= (1<<EEWE);
	
//}*/

//reading from eeprom
/*unsigned char *EEPROM_read(unsigned int uiAddress)
{
	/* Wait for completion of previous write */
	//while(EECR & (1<<EEWE));
	/* Set up address register */
	//EEAR = uiAddress;
	/* Start eeprom read by writing EERE */
	//EECR |= (1<<EERE);
	/* Return data from data register */
	//return EEDR;
//}*/
	
//char *EEPROM_read(unsigned int uiAddress)
//{
	//char buffer[4000]; // Assuming a maximum string length
	//int length = 0;

	//while (1) {
		/* Wait for completion of previous write */
		//while (EECR & (1 << EEWE));
		/* Set up address register */
		//EEAR = uiAddress + length;
		/* Start EEPROM read by writing EERE */
		//EECR |= (1 << EERE);

		//char ch = EEDR;

		//if (ch == '\0' || length >= 4000 - 1) {
			//break; // Null-terminator or maximum length reached
		//}

		//buffer[length] = ch;
		//length++;
	//}

	//buffer[length] = '\0'; // Null-terminate the string
	//return strdup(buffer);
//}

//eeprom
//unsigned int eeprom_address=0x00;
//unsigned char write_string[] = {"Hello World"}, read_string[15];
	


void serial_console(){
	
	//writing to eeprom
	//EEPROM_WriteString(eeprom_address,write_string);  // Write the String at memory Location 0x00
	//EEPROM_write(0x5, 'A');

	//char myString[] = "Number of tourists 10 and below: 5, Number of tourists above 10: 10"; // Your string
	//myString[sizeof(myString) - 1] = '\0'; // Null-terminate the string

	// Now, you can store the null-terminated string in EEPROM
	//EEPROM_write(0x5, myString);


	USART_Transmit_str("       QUEENELIZABETH NATIONAL PARK \r\n");
	USART_Transmit_str("1) How much do tourists who are ten and below pay as well as those above ten? \r\n");
	USART_Transmit_str("2) How many tourists, categorized by age group are in the park? \r\n");
	USART_Transmit_str("3) Which vehicles are still in the park? \r\n");
	USART_Transmit_str("4) How much has been collected by the park aggregated by the fridge money and entrance? \r\n");
	USART_Transmit_str("5) How many drivers are in the park? \r\n");
	USART_Transmit_str("6) Number of bottles in the fridge \r\n");
	USART_Transmit_str("7) Replenish Fridge \r\n");
	USART_Transmit_str("8) Login \r\n");
	USART_Transmit_str("9) How many cars are waiting outside the park? \r\n");
	USART_Transmit_str("10) Is park full or not? \r\n");
	

	USART_Transmit_str("ENTER YOUR CHOICE BELOW: \r\n");
	char choice=USART_Receive();
	USART_Transmit(choice);
	USART_Transmit_str("\r\n");
	
	char R_array[40],W_array[40] = "Ten and below:5000, Above ten:10000";
	memset(R_array,0,15);
	eeprom_busy_wait();		/* Initialize LCD */
	eeprom_write_block(W_array,0,strlen(W_array));	/* Write W_array 
							from EEPROM address 0 */
	
	//char *case1;
	switch(choice){
		case '1':
		//implement code here
		//case1 = EEPROM_ReadString(eeprom_address,read_string);   // Read the String from memory Location 0x00	
		eeprom_read_block(R_array,0,strlen(W_array));	/* Read EEPROM from address 0 */
		USART_Transmit_str(R_array);
		USART_Transmit_str("\r\n");
		//free(case1); // Free the dynamically allocated memory
		break;

		case '2':
		//implement code here
		break;
		case '3':
		//implement code here
		break;

		case '4':
		//implement code here
		break;
		case '5':
		//implement code here
		break;
		case '6':
		//implement code here
		break;

		case '7':
		//implement code here
		break;

		case '8':
		//implement code here
		break;

		case '9':
		//implement code here
		break;

		default:
		//implement code here
		break;
	}

}


int main(void)
{	
    /* Replace with your application code */
	
	
	//serial communication
	USART_Init ( MYUBRR );
	
	DDRD = 0X00;
	DDRE = 0XFF;
	DDRF = 0XFF;
	DDRG = 0XFF;
	DDRA = 0xff;
	DDRB = 0xff;
	DDRC = 0B00000111; //  row-input (00000),column- output (111)
	PORTB |= (1<<3); //sounding the buzzer
	sei(); //enabling global interrupts using the i bit of the sreg register
	EIMSK |= (1<<INT0); //enabling interrupts at int0 port
	EICRA |= (1<<ISC00);//on any logical change
	TCCR0 |= (1<<CS00); //setting for no prescaling
	TCNT0 = 0X00; //setting to start counting from 0
	TIMSK |= (1<<TOIE0); //enabling interrupts for timers
	

	/* Replace with your application code */
	while (1)
	{
		//serial communication
		serial_console();
		
		
		//printing price of water bottles.
		PORTC = 0b11111110; //setting column 1 to have a 0 for testing
		if((PINC&0b00001000)==0x00){ //if there is a 0 at row 1, then 1 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "1500";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
				
				
			}
		}if((PINC&0b00010000)==0x00){ //if there is a 0 at row 2, then 4 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "6000";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
				
				
			}
		}if((PINC&0b00100000)==0x00){ //if there is a zero at row 3, then 7 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "10500";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<5; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}
		
		
		PORTC = 0b11111101; //setting column 2 to 0 for testing
		if((PINC&0b00001000)==0x00){ //if there is a 0 at row 1, then 2 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "3000";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}if((PINC&0b00010000)==0x00){ //if there is a 0 at row 2, then 5 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "7500";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}if((PINC&0b00100000)==0x00){ //if there is a zero at row 3, then 8 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "12000";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<5; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}
		
		
		PORTC = 0b11111011; //setting column 3 to 0 for testing
		if((PINC&0b00001000)==0x00){ //if there is a 0 at row 1, then 3 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "4500";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}if((PINC&0b00010000)==0x00){ //if there is a 0 at row 2, then 6 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
			
			
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
			
			//printing amount
			char word[] = "9000";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<4; y++){
				PORTF = word[y];
				PORTG &= ~(1<<2); //putting 0 at enable pin
				_delay_ms(1);
				PORTG |= (1<<2); //putting 1 at enable pin
			}
		}if((PINC&0b00100000)==0x00){ //if there is a zero at row 3, then 9 is pressed
			PORTG &= ~(1<<0); //RS-0-COMMAND
			PORTG &= ~(1<<1); //RW-0-WRITE
		
			//turn display on, cursor on and blink
			PORTF = 0B00001111;
			//latching
			PORTG &= ~(1<<2); //setting enable (e) to 0
			_delay_ms(1000);
			PORTG |= (1<<2); //setting it to high (1)
		
		
			//clearing screen
			PORTF = 0b00000001;
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1000);
			PORTG |= (1<<2); //putting 1 at enable pin
		
			//printing amount
			char word[] = "13500";
			PORTG |= (1<<0); //DATA MODE RS
			PORTG &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<5; y++){
			PORTF = word[y];
			PORTG &= ~(1<<2); //putting 0 at enable pin
			_delay_ms(1);
			PORTG |= (1<<2); //putting 1 at enable pin
			}
		}
	}
	
	
}

/*ISR(INT0_vect){
	PORTF ^= (1<<0);
	PORTE &= ~(1<<0); //turn off the buzzer

		PORTB &= ~(1<<2); //RS-0-COMMAND
		PORTB &= ~(1<<1); //RW-0-WRITE
		
		//turn display on, cursor on and blink
		PORTA = 0B00001111;
		//latching
		PORTB &= ~(1<<0); //setting enable (e) to 0
		_delay_ms(1000);
		PORTB |= (1<<0); //setting it to high (1)
		
		//clearing screen
		PORTA = 0b00000001;
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1000);
		PORTB |= (1<<0); //putting 1 at enable pin
		
		//printing car at gate
		PORTB |= (1<<2); //DATA MODE RS
		PORTB &= ~(1<<1); //RW-0-WRITE
		for (int y=0; y<11; y++){
			PORTA = word[y];
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1);
			PORTB |= (1<<0); //putting 1 at enable pin
		
		}

}*/


ISR(TIMER0_OVF_vect){  //setting an interrupt after one second
	PORTB &= ~(1<<3); //turn off the buzzer
	count++;
	if(count==3922){  //3922 times of overflows are roughly needed to make a second, 1000000/255=3922
		

		PORTB &= ~(1<<2); //RS-0-COMMAND
		PORTB &= ~(1<<1); //RW-0-WRITE 
		
		//turn display on, cursor on and blink
		PORTA = 0B00001111;
		//latching
		PORTB &= ~(1<<0); //setting enable (e) to 0
		_delay_ms(1000);
		PORTB |= (1<<0); //setting it to high (1)
		
		
		//clearing screen
		PORTA = 0b00000001;
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1000);
		PORTB |= (1<<0); //putting 1 at enable pin
		
		//printing car at gate
		char word[] = "Car at gate";
		PORTB |= (1<<2); //DATA MODE RS
		PORTB &= ~(1<<1); //RW-0-WRITE
		for (int y=0; y<11; y++){
		PORTA = word[y];
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1);
		PORTB |= (1<<0); //putting 1 at enable pin
		}

		//count = 0;
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
	//count++;
	if(count==7844){  //7843 times of overflows are roughly needed to make 2 seconds, 2000000/255=7843, 11765
		PORTB &= ~(1<<2); //RS-0-COMMAND
		PORTB &= ~(1<<1); //RW-0-WRITE
		
		//turn display on, cursor on and blink
		PORTA = 0B00001111;
		//latching
		PORTB &= ~(1<<0); //setting enable (e) to 0
		_delay_ms(1000);
		PORTB |= (1<<0); //setting it to high (1)
		
		//clearing screen
		PORTA = 0b00000001;
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1000);
		PORTB |= (1<<0); //putting 1 at enable pin
		
		//printing gate opening
		char word[] = "Gate opening";
		PORTB |= (1<<2); //DATA MODE RS
		PORTB &= ~(1<<1); //RW-0-WRITE
		for (int y=0; y<12; y++){
		PORTA = word[y];
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1);
		PORTB |= (1<<0); //putting 1 at enable pin
		
		}

		//count = 0;
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
	//count++;	
	if(count==11766){  // 3 seconds, 3000000/255=11,764.7
			PORTB &= ~(1<<2); //RS-0-COMMAND
			PORTB &= ~(1<<1); //RW-0-WRITE
			
			//turn display on, cursor on and blink
			PORTA = 0B00001111;
			//latching
			PORTB &= ~(1<<0); //setting enable (e) to 0
			_delay_ms(1000);
			PORTB |= (1<<0); //setting it to high (1)
			
			//clearing screen
			PORTA = 0b00000001;
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1000);
			PORTB |= (1<<0); //putting 1 at enable pin
			
			//printing registration
			char word[] = "Registration";
			PORTB |= (1<<2); //DATA MODE RS
			PORTB &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<12; y++){
			PORTA = word[y];
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1);
			PORTB |= (1<<0); //putting 1 at enable pin
			
			}

			//count = 0;
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
			
	//count++;		
	if(count==15688){  // 3 seconds, 3000000/255=11,764.7
			PORTB &= ~(1<<2); //RS-0-COMMAND
			PORTB &= ~(1<<1); //RW-0-WRITE
				
			//turn display on, cursor on and blink
			PORTA = 0B00001111;
			//latching
			PORTB &= ~(1<<0); //setting enable (e) to 0
			_delay_ms(1000);
			PORTB |= (1<<0); //setting it to high (1)
				
			//clearing screen
			PORTA = 0b00000001;
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1000);
			PORTB |= (1<<0); //putting 1 at enable pin
				
			//printing car entering
			char word[] = "Car entering";
			PORTB |= (1<<2); //DATA MODE RS
			PORTB &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<12; y++){
			PORTA = word[y];
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1);
			PORTB |= (1<<0); //putting 1 at enable pin
							
			}

				//count = 0;		
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
	//count++;
	if(count==27454){  // 3 seconds, 3000000/255=11,764.7
			PORTB &= ~(1<<2); //RS-0-COMMAND
			PORTB &= ~(1<<1); //RW-0-WRITE
				
			//turn display on, cursor on and blink
			PORTA = 0B00001111;
			//latching
			PORTB &= ~(1<<0); //setting enable (e) to 0
			_delay_ms(1000);
			PORTB |= (1<<0); //setting it to high (1)
				
				
			//clearing screen
			PORTA = 0b00000001;
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1000);
			PORTB |= (1<<0); //putting 1 at enable pin
				
			//printing car entering
			char word[] = "Gate closing";
			PORTB |= (1<<2); //DATA MODE RS
			PORTB &= ~(1<<1); //RW-0-WRITE
			for (int y=0; y<12; y++){
			PORTA = word[y];
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1);
			PORTB |= (1<<0); //putting 1 at enable pin
							
			}

				//count = 0;			
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
	
	if(count==35298){  // 3 seconds, 3000000/255=11,764.7
		PORTB &= ~(1<<2); //RS-0-COMMAND
		PORTB &= ~(1<<1); //RW-0-WRITE
		
		//turn display on, cursor on and blink
		PORTA = 0B00001111;
		//latching
		PORTB &= ~(1<<0); //setting enable (e) to 0
		_delay_ms(1000);
		PORTB |= (1<<0); //setting it to high (1)
		
		//clearing screen
		PORTA = 0b00000001;
		PORTB &= ~(1<<0); //putting 0 at enable pin
		_delay_ms(1000);
		PORTB |= (1<<0); //putting 1 at enable pin
		
		//printing gate closed
		char word[] = "Gate closed";
		PORTB |= (1<<2); //DATA MODE RS
		PORTB &= ~(1<<1); //RW-0-WRITE
		for (int y=0; y<11; y++){
			PORTA = word[y];
			PORTB &= ~(1<<0); //putting 0 at enable pin
			_delay_ms(1);
			PORTB |= (1<<0); //putting 1 at enable pin	
			
		}

		//count = 0;	
	}
	TIFR &= ~(1<<TOV0); //unsetting the TOV0 bit after overflow
			
}	
    



